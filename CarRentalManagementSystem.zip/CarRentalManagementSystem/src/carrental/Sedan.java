package carrental;

public class Sedan extends Car {

    public Sedan(String registrationNumber, String model) {
        super(registrationNumber, model);
    }

    @Override
    public double calculateRentalFee(int days) {
        return days * 70; // Higher fee for Sedan
    }
}
