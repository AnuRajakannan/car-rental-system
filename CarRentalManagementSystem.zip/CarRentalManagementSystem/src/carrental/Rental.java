package carrental;

public class Rental {
    private Car car;
    private Customer customer;
    private int rentalDays;

    public Rental(Car car, Customer customer, int rentalDays) {
        this.car = car;
        this.customer = customer;
        this.rentalDays = rentalDays;
    }

    public double calculateTotalFee() {
        return car.calculateRentalFee(rentalDays);
    }

    @Override
    public String toString() {
        return "Rental{" +
                "car=" + car +
                ", customer=" + customer +
                ", rentalDays=" + rentalDays +
                ", totalFee=" + calculateTotalFee() +
                '}';
    }
}
