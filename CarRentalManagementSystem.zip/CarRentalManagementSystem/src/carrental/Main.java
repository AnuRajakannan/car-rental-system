package carrental;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Car> cars = new ArrayList<>();
        cars.add(new Sedan("ABC123", "Toyota Camry"));
        cars.add(new SUV("XYZ456", "Ford Explorer"));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Car Rental System");
            System.out.println("1. View Cars");
            System.out.println("2. Rent a Car");
            System.out.println("3. Return a Car");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Available Cars:");
                    for (Car car : cars) {
                        if (!car.isRented()) {
                            System.out.println(car);
                        }
                    }
                    break;

                case 2:
                    System.out.print("Enter your name: ");
                    scanner.nextLine(); // consume newline
                    String name = scanner.nextLine();
                    System.out.print("Enter your driving license: ");
                    String license = scanner.nextLine();
                    Customer customer = new Customer(name, license);

                    System.out.print("Enter car registration number to rent: ");
                    String regNumber = scanner.nextLine();

                    Car carToRent = null;
                    for (Car car : cars) {
                        if (car.getRegistrationNumber().equalsIgnoreCase(regNumber) && !car.isRented()) {
                            carToRent = car;
                            break;
                        }
                    }

                    if (carToRent == null) {
                        System.out.println("Car not available!");
                    } else {
                        System.out.print("Enter number of rental days: ");
                        int days = scanner.nextInt();
                        carToRent.rentCar();
                        Rental rental = new Rental(carToRent, customer, days);
                        System.out.println("Rental successful! Details: " + rental);
                    }
                    break;

                case 3:
                    System.out.print("Enter car registration number to return: ");
                    scanner.nextLine(); // consume newline
                    String regToReturn = scanner.nextLine();

                    Car carToReturn = null;
                    for (Car car : cars) {
                        if (car.getRegistrationNumber().equalsIgnoreCase(regToReturn) && car.isRented()) {
                            carToReturn = car;
                            break;
                        }
                    }

                    if (carToReturn == null) {
                        System.out.println("Car not found or already returned!");
                    } else {
                        carToReturn.returnCar();
                        System.out.println("Car returned successfully!");
                    }
                    break;

                case 4:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}