package carrental;

public class SUV extends Car {

    public SUV(String registrationNumber, String model) {
        super(registrationNumber, model);
    }

    @Override
    public double calculateRentalFee(int days) {
        return days * 100; // Higher fee for SUV
    }
}